######################################################################################################
# This R code illustrates how to use the candidate factor score distribution obtained from SFA Prime #
######################################################################################################

#install.packages('R.matlab')
library(R.matlab)
ScoreMatrix=readMat('Result_Tutorial01_Simple_S1b_CFSD.mat')
ScoreMatrix$Single.CFS   # A single candidate factor score matrix (for secondary analysis)  
ScoreMatrix$Expected.CFS # An expected candidate factor score matrix (for diagnosis)
ScoreMatrix$Set.CFSD     # A set of candidate factor score matrices (=Candidate factor score distribution)

hist(ScoreMatrix$Set.CFSD[1,4,]) # ID 1's Textual factor scores 
hist(ScoreMatrix$Set.CFSD[6,4,]) # ID 6's Textual factor scores 

hist(ScoreMatrix$Set.CFSD[1,4,]-ScoreMatrix$Set.CFSD[6,4,]) 
  # The distribution of differences in candidate Textual factor scores between ID 1 and ID 6

N_rep = length(ScoreMatrix$Set.CFSD[1,1,]) # Number of candidate factor score matrices
sum((ScoreMatrix$Set.CFSD[1,4,]-ScoreMatrix$Set.CFSD[6,4,])>0)/N_rep 
  # Probability that ID 1 may have a higher textual factor score than ID 6. 