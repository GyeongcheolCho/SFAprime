#install.packages('R.matlab')
library(R.matlab)
CFSD=readMat('Result_Tutorial01_S2b_CFSD.mat')
CFSD$Set.H            # A set of candidate factor score matrices without calibration  
CFSD$Set.H.calibrated # A set of candidate factor score matrices with calibration 
# Using the latter one is recommended when the number of candidate factor score matrices is small
